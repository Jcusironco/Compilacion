﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class Caja
    {
        private string ingresos;
        private string egresos;
        private string compras;

        public string Ingresos { get => ingresos; set => ingresos = value; }
        public string Egresos { get => egresos; set => egresos = value; }
        public string Compras { get => compras; set => compras = value; }

        public string ReporteCompras()
        {
            return "Metodo reporte de compras no esta implementado";
        }
        public string ReporteVentas()
        {
            return "Metodo reporte de ventas no esta implementado";
        }
        public string ReporteGastos()
        {
            return "Metodo reporte de gastos no esta implementado";
        }
        public string CierreCaja()
        {
            return "Metodo cierre de caja no esta implementado";
        }

    }
}
