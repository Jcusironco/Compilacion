﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class Proveedor
    {
        private string dicitribuidor;
        private string direccion;

        public string Dicitribuidor { get => dicitribuidor; set => dicitribuidor = value; }
        public string Direccion { get => direccion; set => direccion = value; }

        public string Distribuir()
        {
            return "Metodo distribuir no esta implementado";
        }
        public string Vender()
        {
            return "Metodo vender no esta implementado";
        }
    }
}
