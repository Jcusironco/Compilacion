﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class Producto
    {
        private string nombres;
        private int codigo;
        private string precio;
        private string fechaVencimiento;
        private string fechaFabricacion;

        public string Nombres { get => nombres; set => nombres = value; }
        public int Codigo { get => codigo; set => codigo = value; }
        public string Precio { get => precio; set => precio = value; }
        public string FechaVencimiento { get => fechaVencimiento; set => fechaVencimiento = value; }
        public string FechaFabricacion { get => fechaFabricacion; set => fechaFabricacion = value; }

        public string Curar()
        {
            return "Metodo curar no esta implementado";
        }
        public string Caducar()
        {
            return "Metodo caducar no esta implementado";
        }
    }
}
