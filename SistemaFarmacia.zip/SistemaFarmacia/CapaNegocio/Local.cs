﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class Local
    {
        private string domicilioFiscal;
        private string domicilioSucursal;
        private string direccion;

        public string DomicilioFiscal { get => domicilioFiscal; set => domicilioFiscal = value; }
        public string DomicilioSucursal { get => domicilioSucursal; set => domicilioSucursal = value; }
        public string Direccion { get => direccion; set => direccion = value; }

        public string GeneralIngresos()
        {
            return "Metodo general ingresos no esta implementado";
        }
        public string DistribuirProductos()
        {
            return "Metodo distribuir productos no esta implementado";
        }

    }
}
