﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class QF
    {
        private string nombres;
        private string experienciaLaborial;
        private int edad;
        private string elaborar;

        public string Nombres { get => nombres; set => nombres = value; }
        public string ExperienciaLaborial { get => experienciaLaborial; set => experienciaLaborial = value; }
        public int Edad { get => edad; set => edad = value; }
        public string Elaborar { get => elaborar; set => elaborar = value; }

        public string AprobarExperimento()
        {
            return "Metodo aprobar experimento no esta implementado";
        }
        public string DesaprobarExperimento()
        {
            return "Metodo desaprobar experimentono no esta implementado";
        }

    }
}