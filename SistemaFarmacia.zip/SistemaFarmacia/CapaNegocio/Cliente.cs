﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class Cliente
    {
        private string nombres;
        private int edad;
        private int dni;
        private string dolencia;
        private string tiempoMalestar;

        public string Nombres { get => nombres; set => nombres = value; }
        public int Edad { get => edad; set => edad = value; }
        public int Dni { get => dni; set => dni = value; }
        public string Dolencia { get => dolencia; set => dolencia = value; }
        public string TiempoMalestar { get => tiempoMalestar; set => tiempoMalestar = value; }

        public string PedirMedicamento()
        {
            return "Metodo pedir medicamento no esta implementado";
        }
        public string Comprar()
        {
            return "Metodo comprar no esta implementado";
        }
        public string Pagar()
        {
            return "Metodo pagar no esta implementado";
        }

    }
}
