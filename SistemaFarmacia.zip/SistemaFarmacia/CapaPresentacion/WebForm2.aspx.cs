﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapaPresentacion
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        private static CapaNegocio.QF Tenico= new CapaNegocio.QF();
        protected void btnLeer_Click(object sender, EventArgs e)
        {
           
            string nombres = txtNombres.Text;
            string experienciaLaborial = txtExperienciaLaborial.Text;
            int  edad = int.Parse(txtEdad.Text); 
            string elaborar = txtElaborar.Text;
            Tenico.Nombres = nombres;
            Tenico.ExperienciaLaborial = experienciaLaborial;
            Tenico.Edad = edad;
            Tenico.Elaborar = elaborar;
            // ENVIAR UN MENSAJE DE CONFORMIDAD
            Response.Write(" Se a registrado correctamente los datos ");
        }
        protected void btnEscribir_Click(object sender, EventArgs e)
        {
            // Escribir los atributos del objeto
            Response.Write( " <br> Nombre:" + Tenico.Nombres +
                "<br> Experiencia Laboral:" + Tenico.ExperienciaLaborial +
                " <br> Estudios:" + Tenico.Edad + " <br> Domicilio:" + Tenico.Elaborar);
        }

        protected void btnAprobarExperimento_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('" + Tenico.AprobarExperimento() + "')</script>");
        }

        protected void btnDesaprobarExperimento_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('" + Tenico.DesaprobarExperimento() + "')</script>");
        }
    }
}