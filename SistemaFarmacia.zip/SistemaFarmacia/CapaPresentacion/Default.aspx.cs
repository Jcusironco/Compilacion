﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapaPresentacion
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnTecnico_Click(object sender, EventArgs e)
        {
            // Llamar al formulario del tecnico
            Response.Redirect("WebForm1.aspx");
        }

        protected void btnQF_Click(object sender, EventArgs e)
        {
            // Llamar al formulario del tecnico
            Response.Redirect("WebForm2.aspx");
        }

        protected void btnProveedor_Click(object sender, EventArgs e)
        {
            // Llamar al formulario del tecnico
            Response.Redirect("WebForm3.aspx");
        }

        protected void btnProducto_Click(object sender, EventArgs e)
        {
            // Llamar al formulario del tecnico
            Response.Redirect("WebForm4.aspx");
        }

        protected void btnLocal_Click(object sender, EventArgs e)
        {
            // Llamar al formulario del tecnico
            Response.Redirect("WebForm5.aspx");
        }
        protected void btnCliente_Click(object sender, EventArgs e)
        {
            // Llamar al formulario del tecnico
            Response.Redirect("WebForm6.aspx");
        }
        protected void btnCaja_Click(object sender, EventArgs e)
        {
            // Llamar al formulario del tecnico
            Response.Redirect("WebForm7.aspx");
        }
    }
}