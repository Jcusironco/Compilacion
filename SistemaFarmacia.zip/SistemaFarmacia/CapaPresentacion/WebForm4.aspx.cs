﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapaPresentacion
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //istanciar la clase a traves de un objeto
        // en esta parte del codigo se declara variables globales
        private static CapaNegocio.Producto  Ns = new CapaNegocio.Producto();

        protected void btnLeer_Click(object sender, EventArgs e)
        {
            string nombres = txtNombres.Text;
            int codigo = int.Parse(txtCodigo.Text);
            string precio = txtPrecio.Text;
            string fechaVencimiento = txtFechaVencimiento.Text;
            string fechaFabricacion = txtFechaFabricacion.Text;
            Ns.Nombres = nombres;
            Ns.Codigo = codigo;
            Ns.Precio = precio;
            Ns.FechaVencimiento = fechaVencimiento;
            Ns.FechaFabricacion = fechaFabricacion;
            // ENVIAR UN MENSAJE DE CONFORMIDAD
            Response.Write("Se a registrado correctamente los datos ");
        }

        protected void btnEcribir_Click(object sender, EventArgs e)
        {
            // Escribir los atributos del objeto
            Response.Write(" <br> Nombres:" + Ns.Nombres + " <br> Codigo:" + Ns.Codigo +
                "<br> Precio:" + Ns.Precio +
                " <br> FechaVencimiento:" + Ns.FechaVencimiento + " <br> FechaFabricacion:" + Ns.FechaFabricacion);
        }

        protected void btnCurar_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('" + Ns.Curar() + "')</script>");
        }

        protected void btnCaducar_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('" + Ns.Caducar() + "')</script>");
        }

        protected void txtNombres_TextChanged(object sender, EventArgs e)
        {

        }
    }
}