﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapaPresentacion
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        private static CapaNegocio.Local Ns = new CapaNegocio.Local();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLeer_Click(object sender, EventArgs e)
        {
            string domicilioFiscal = txtDomicilioFiscal.Text;
            string domicilioSucursal = txtDomicilioSucursal.Text;
            string direccion = txtDireccion.Text;
            Ns.DomicilioFiscal = domicilioFiscal;
            Ns.DomicilioSucursal = domicilioSucursal;
            Ns.Direccion = direccion;
            // ENVIAR UN MENSAJE DE CONFORMIDAD
            Response.Write("Se a registrado correctamente los datos ");
        }

        protected void btnEscribir_Click(object sender, EventArgs e)
        {
            // Escribir los atributos del objeto
            Response.Write(" <br> Domicilio Fiscal :" + Ns.DomicilioFiscal + " <br> Domicilio Sucursal :" + Ns.DomicilioSucursal +
                "<br> Direccion :" + Ns.Direccion);
        }

        protected void btnGeneralIngresos_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('" + Ns.GeneralIngresos() + "')</script>");
        }

        protected void btnDistribuirProductos_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('" + Ns.DistribuirProductos() + "')</script>");
        }
    }
}