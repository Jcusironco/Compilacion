﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapaPresentacion
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        private static CapaNegocio.Proveedor Ns= new CapaNegocio.Proveedor();
        protected void btnLeer_Click(object sender, EventArgs e)
        {
            string dicitribuidor = txtDicitribuidor.Text;
            string direccion = txtDireccion.Text;
            Ns.Dicitribuidor = dicitribuidor;
            Ns.Direccion = direccion;
      
            // ENVIAR UN MENSAJE DE CONFORMIDAD
            Response.Write(" Se a registrado correctamente los datos ");
        }

        protected void btnEscribir_Click(object sender, EventArgs e)
        {
            // Escribir los atributos del objeto
            Response.Write(" <br> Dicitribuidor:" + Ns.Dicitribuidor +
                "<br> Direccion :" + Ns.Direccion);
               
        }

        protected void btnDistribuir_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('" + Ns.Distribuir() + "')</script>");
        }

        protected void btnVender_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('" + Ns.Vender() + "')</script>");
        }
    }
}