﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapaPresentacion
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //istanciar la clase a traves de un objeto
        // en esta parte del codigo se declara variables globales
        private static CapaNegocio.Tecnico  TenicoN= new CapaNegocio.Tecnico();
        protected void btnLeer_Click(object sender, EventArgs e)
        {
            string apellidos = txtApellidos.Text;
            string nombres = txtNombres.Text;
            string experienciaLaboral = txtExperienciaLaboral.Text;
            string estudios = txtEstudios.Text;
            string domicilio = txtDomicilio.Text;

            if (apellidos == "")
                Response.Write("ingrese apellidos");
            else if (nombres == string.Empty)
                Response.Write("ingrese nombre");
            else if (experienciaLaboral.Equals(""))
                Response.Write("<script>alert(' ingrese experiencia Laboral');</script>");
            else if (estudios == string.Empty)
                Response.Write("<script>alert(' ingrese estudios');</script>");
            else if (domicilio == string.Empty)
                Response.Write("<script>alert(' ingrese domicilio');</script>");

            TenicoN.Apellidos = apellidos;
            TenicoN.Nombres = nombres;
            TenicoN.ExperienciaLaboral = experienciaLaboral;
            TenicoN.Estudios = estudios;
            TenicoN.Domicilio = domicilio;
            // ENVIAR UN MENSAJE DE CONFORMIDAD
            Response.Write("Se a registrado correctamente los datos ");
        }
        protected void btnEscribir_Click(object sender, EventArgs e)
        {
            // Escribir los atributos del objeto
            Response.Write(" <br> Apellidos:" + TenicoN.Apellidos + " <br> Nombre:" + TenicoN.Nombres +
                "<br> Experiencia Laboral:" + TenicoN.ExperienciaLaboral +
                " <br> Estudios:" + TenicoN.Estudios + " <br> Domicilio:" + TenicoN.Domicilio);
        }

        protected void btnControlarVentas_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('"+ TenicoN.ControlarVentas() + "')</script>");
        }

        protected void btnAtenderClientes_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('" + TenicoN.AtenderClientes()+ "')</script>");
        }

        protected void btnBalanceDiario_Click(object sender, EventArgs e)
        {
            Response.Write(TenicoN.BalanceDiario());
        }
    }
}