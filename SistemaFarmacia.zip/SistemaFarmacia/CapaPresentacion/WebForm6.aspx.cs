﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapaPresentacion
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        private static CapaNegocio.Cliente Ns = new CapaNegocio.Cliente();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLeer_Click(object sender, EventArgs e)
        {
            string nombres = txtNombres.Text;
            int edad = int.Parse(txtEdad.Text);
            int dni = int.Parse(txtDni.Text);
            string dolencia = txtDolencia.Text;
            string tiempoMalestar = txtTiempoMalestar.Text;
            Ns.Nombres = nombres;
            Ns.Edad = edad;
            Ns.Dni = dni;
            Ns.Dolencia = dolencia;
            Ns.TiempoMalestar = tiempoMalestar;
            // ENVIAR UN MENSAJE DE CONFORMIDAD
            Response.Write("Se a registrado correctamente los datos ");
        }

        protected void btnEscribir_Click(object sender, EventArgs e)
        {
            // Escribir los atributos del objeto
            Response.Write(" <br> Nombres:" + Ns.Nombres + " <br> Edad :" + Ns.Edad +
                "<br>  Dni:" + Ns.Dni +
                " <br> Dolencia:" + Ns.Dolencia + " <br> TiempoMalestar:" + Ns.TiempoMalestar);
        }

        protected void btnComprar_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('" + Ns.Comprar() + "')</script>");
        }

        protected void btnPedirMedicamento_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('" + Ns.PedirMedicamento() + "')</script>");
        }

        protected void btnPagar_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('" + Ns.Pagar() + "')</script>");
        }
    }
}