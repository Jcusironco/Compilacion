﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapaPresentacion
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        private static CapaNegocio.Caja Ns = new CapaNegocio.Caja();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLeer_Click(object sender, EventArgs e)
        {
            string ingresos = txtIngresos.Text;
            string egresos = txtEgresos.Text;
            string compras = txtCompras.Text;
            Ns.Ingresos = ingresos;
            Ns.Egresos = egresos;
            Ns.Compras = compras;
            // ENVIAR UN MENSAJE DE CONFORMIDAD
            Response.Write("Se a registrado correctamente los datos ");
        }

        protected void btnEscribir_Click(object sender, EventArgs e)
        {
            // Escribir los atributos del objeto
            Response.Write(" <br> Ingresos:" + Ns.Ingresos + " <br> Egresos :" + Ns.Egresos +
                "<br> Compras:" + Ns.Compras );
        }

        protected void btnReporteCompras_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('" + Ns.ReporteCompras() + "')</script>");
        }

        protected void btnReporteVentas_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('" + Ns.ReporteVentas() + "')</script>");
        }

        protected void btnReporteGastos_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('" + Ns.ReporteGastos() + "')</script>");
        }

        protected void btnCierreCaja_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('" + Ns.CierreCaja() + "')</script>");
        }
    }
}