﻿Public Class Cliente
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
    Dim Ns As New CapaNegocio.Cliente
    Protected Sub btnLeer_Click(sender As Object, e As EventArgs) Handles btnLeer.Click
        Ns.Cantidad = txtCantidad.Text
        Ns.Precio = txtPrecio.Text
        Ns.ComprobantePago = txtComprobantePago.Text
        Ns.Direccion = txtDireccion.Text
        Ns.Telefono = txtTelefono.Text
        Ns.Email = txtEmail.Text
        Response.Write("se han regitardo correctamente los datos")
    End Sub

    Protected Sub btnEscribir_Click(sender As Object, e As EventArgs) Handles btnEscribir.Click

        Response.Write(" <br> Cantidad:" + txtCantidad.Text + "<br> Precio:" + txtPrecio.Text + "<br> ComprobantePago:" + txtComprobantePago.Text +
                       " <br>Direccion:" + txtDireccion.Text + " <br> Telefono:" + txtTelefono.Text + " <br> Email:" + txtEmail.Text)

    End Sub

    Protected Sub btnComprarProducto_Click(sender As Object, e As EventArgs) Handles btnComprarProducto.Click
        Response.Write("<script>alert('" + Ns.ComprarProducto + "')</script>")
    End Sub

    Protected Sub btnPagarProducto_Click(sender As Object, e As EventArgs) Handles btnPagarProducto.Click
        Response.Write("<script>alert('" + Ns.PagarProducto + "')</script>")
    End Sub

    Protected Sub btnOrganizacion_Click(sender As Object, e As EventArgs) Handles btnOrganizacion.Click
        Response.Write("<script>alert('" + Ns.Organizacion + "')</script>")
    End Sub

    Protected Sub btnRecibirProducto_Click(sender As Object, e As EventArgs) Handles btnRecibirProducto.Click
        Response.Write("<script>alert('" + Ns.RecibirProducto + "')</script>")
    End Sub

    Protected Sub btnRegresar_Click(sender As Object, e As EventArgs) Handles btnRegresar.Click
        Response.Redirect("Principal.aspx")
    End Sub
End Class