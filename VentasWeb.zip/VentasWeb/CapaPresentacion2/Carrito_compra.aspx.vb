﻿Public Class Carrito_compra
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Dim admin1 As New CapaNegocio.Carrito_compra
    Protected Sub btnLeer_Click(sender As Object, e As EventArgs) Handles btnLeer.Click
        admin1.Cantidad = txtCantidad.Text
        admin1.Precio = txtPrecio.Text
        admin1.FechaCreacion = calFechaCreacion.TodaysDate
        Response.Write("se han regitardo correctamente los datos")
    End Sub

    Protected Sub btnEscribir_Click(sender As Object, e As EventArgs) Handles btnEscribir.Click

        Response.Write(" Cantidad:" + txtCantidad.Text + "Precio:" + txtPrecio.Text + " FechaCreacion:" + calFechaCreacion.TodaysDate)
    End Sub

    Protected Sub btnVentaProducto_Click(sender As Object, e As EventArgs) Handles btnVentaProducto.Click
        Response.Write("<script>alert('" + admin1.VentaProducto + "')</script>")
    End Sub
    Protected Sub btnAgregarProducto_Click(sender As Object, e As EventArgs) Handles btnAgregarProducto.Click
        Response.Write("<script>alert('" + admin1.AgregarProducto + "')</script>")
    End Sub
    Protected Sub btnOrganizacion_Click(sender As Object, e As EventArgs) Handles btnOrganizacion.Click
        Response.Write("<script>alert('" + admin1.Organizacion + "')</script>")
    End Sub
    Protected Sub btnRegresar_Click(sender As Object, e As EventArgs) Handles btnRegresar.Click
        Response.Redirect("Principal.aspx")
    End Sub
End Class