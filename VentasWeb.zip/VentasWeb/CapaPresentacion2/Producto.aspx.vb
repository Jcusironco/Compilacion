﻿Public Class Producto
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
    Dim Ns As New CapaNegocio.Producto
    Protected Sub btnLeer_Click(sender As Object, e As EventArgs) Handles btnLeer.Click
        Ns.Cantidad = txtCantidad.Text
        Ns.Precio = txtPrecio.Text
        Ns.Nombre = txtNombre.Text
        Ns.Calidad = txtCalidad.Text
        Ns.Proveedor = txtProveedor.Text
        Ns.Garantia = txtGarantia.Text
        Response.Write("se han regitardo correctamente los datos")
    End Sub

    Protected Sub btnEscribir_Click(sender As Object, e As EventArgs) Handles btnEscribir.Click
        Response.Write(" <br> Cantidad:" + txtCantidad.Text + "<br> Precio:" + txtPrecio.Text + "<br> Nombre :" + txtNombre.Text +
                       " <br> Calidad :" + txtCalidad.Text + " <br> Proveedor :" + txtProveedor.Text + " <br> Garantia :" + txtGarantia.Text)
    End Sub

    Protected Sub btnTiempoVida_Click(sender As Object, e As EventArgs) Handles btnTiempoVida.Click
        Response.Write("<script>alert('" + Ns.TiempoVida + "')</script>")
    End Sub

    Protected Sub btnUso_Click(sender As Object, e As EventArgs) Handles btnUso.Click
        Response.Write("<script>alert('" + Ns.Uso + "')</script>")
    End Sub

    Protected Sub btnOrganizacion_Click(sender As Object, e As EventArgs) Handles btnOrganizacion.Click
        Response.Write("<script>alert('" + Ns.Organizacion + "')</script>")
    End Sub

    Protected Sub btnRegresar_Click(sender As Object, e As EventArgs) Handles btnRegresar.Click
        Response.Redirect("Principal.aspx")
    End Sub
End Class