﻿Public Class Pedido
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
    Dim Ns As New CapaNegocio.Pedido
    Protected Sub btnLeer_Click(sender As Object, e As EventArgs) Handles btnLeer.Click
        Ns.Cantidad = txtCantidad.Text
        Ns.Precio = txtPrecio.Text
        Ns.Id = txtId.Text
        Ns.FechaRealizacion = txtFechaRealizacion.Text
        Ns.Estado = txtEstado.Text
        Ns.Total = txtTotal.Text
        Response.Write("se han regitardo correctamente los datos")
    End Sub

    Protected Sub btnEscribir_Click(sender As Object, e As EventArgs) Handles btnEscribir.Click
        Response.Write(" <br> Cantidad:" + txtCantidad.Text + "<br> Precio:" + txtPrecio.Text + "<br> Id :" + txtId.Text +
                       " <br>FechaRealizacion :" + txtFechaRealizacion.Text + " <br> Estado :" + txtEstado.Text + "<br> Total :" + txtTotal.Text)
    End Sub

    Protected Sub btnPedirProducto_Click(sender As Object, e As EventArgs) Handles btnPedirProducto.Click
        Response.Write("<script>alert('" + Ns.PedirProducto + "')</script>")
    End Sub

    Protected Sub btnOrganizacion_Click(sender As Object, e As EventArgs) Handles btnOrganizacion.Click
        Response.Write("<script>alert('" + Ns.Organizacion + "')</script>")
    End Sub

    Protected Sub btnRegresar_Click(sender As Object, e As EventArgs) Handles btnRegresar.Click
        Response.Redirect("Principal.aspx")
    End Sub
End Class