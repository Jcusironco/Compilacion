﻿Public Class Envio
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
    Dim Ns As New CapaNegocio.Envio
    Protected Sub btnLeer_Click(sender As Object, e As EventArgs) Handles btnLeer.Click
        Ns.Cantidad = txtCantidad.Text
        Ns.Precio = txtPrecio.Text
        Ns.Id = txtId.Text
        Ns.DireccionFacturacion = txtDireccionFacturacion.Text
        Ns.Finalizado = txtFinalizado.Text
        Ns.FechaVencimiento1 = calFechaVencimiento.TodaysDate
        Ns.Compania = txtCompania.Text
        Response.Write("se han regitardo correctamente los datos")
    End Sub

    Protected Sub btnEscribir_Click(sender As Object, e As EventArgs) Handles btnEscribir.Click
        Response.Write(" <br> Cantidad:" + txtCantidad.Text + "<br> Precio:" + txtPrecio.Text + "<br> Id:" + txtId.Text +
                       " <br>DireccionFacturacion:" + txtDireccionFacturacion.Text + " <br> Finalizado" + txtFinalizado.Text + " <br> FechaVencimiento:" + calFechaVencimiento.TodaysDate + " <br> Compania:" + txtCompania.Text)
    End Sub

    Protected Sub btnEnviarProducto_Click(sender As Object, e As EventArgs) Handles btnEnviarProducto.Click
        Response.Write("<script>alert('" + Ns.EnviarProducto + "')</script>")
    End Sub

    Protected Sub btnOrganizacion_Click(sender As Object, e As EventArgs) Handles btnOrganizacion.Click
        Response.Write("<script>alert('" + Ns.Organizacion + "')</script>")
    End Sub

    Protected Sub btnRegresar_Click(sender As Object, e As EventArgs) Handles btnRegresar.Click
        Response.Redirect("Principal.aspx")
    End Sub
End Class