﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class Envio: LineaProducto
    {
        //Atributos
        private string id;
        private string direccionFacturacion;
        private string finalizado;
        DateTime fechaVencimiento;
        private string compania;
        //Propiedades
        public string Id { get => id; set => id = value; }
        public string DireccionFacturacion { get => direccionFacturacion; set => direccionFacturacion = value; }
        public string Finalizado { get => finalizado; set => finalizado = value; }
        public DateTime FechaVencimiento1 { get => fechaVencimiento; set => fechaVencimiento = value; }
        public string Compania { get => compania; set => compania = value; }
        //Metodos
        public string EnviarProducto()
        {
            return " Este metodo no ha sido implemetado";
        }
    }
}
