﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class Pedido : LineaProducto
    {
        //Atributos
        private string id;
        private string fechaRealizacion;
        private string estado;
        private string total;
        //Propiedades
        public string Id { get => id; set => id = value; }
        public string FechaRealizacion { get => fechaRealizacion; set => fechaRealizacion = value; }
        public string Estado { get => estado; set => estado = value; }
        public string Total { get => total; set => total = value; }
        //Metodos
        public string PedirProducto()
        {
            return " Este metodo no ha sido implemetado";
        }
    }
}
