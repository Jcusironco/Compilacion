﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class Cliente : LineaProducto
    {
        //Atributos
        private string comprobantePago;
        private string direccion;
        private string telefono;
        private string email;
        //Propiedades
        public string ComprobantePago { get => comprobantePago; set => comprobantePago = value; }
        public string Direccion { get => direccion; set => direccion = value; }
        public string Telefono { get => telefono; set => telefono = value; }
        public string Email { get => email; set => email = value; }
        //Metodos
        public string ComprarProducto()
        {
            return " Este metodo no ha sido implemetado";
        }
        public string PagarProducto()
        {
            return " Este metodo no ha sido implemetado";
        }
        public string RecibirProducto()
        {
            return " Este metodo no ha sido implemetado";
        }

    }
}
