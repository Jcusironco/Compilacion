﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class Producto: LineaProducto
    {
        //Atributos
        private string nombre;
        private string calidad;
        private string proveedor;
        private string garantia;
        //Propiedades
        public string Nombre { get => nombre; set => nombre = value; }
        public string Calidad { get => calidad; set => calidad = value; }
        public string Proveedor { get => proveedor; set => proveedor = value; }
        public string Garantia { get => garantia; set => garantia = value; }

        //Metodos
        public string Uso()
        {
            return " Este metodo no ha sido implemetado";
        }
        public string TiempoVida()
        {
            return " Este metodo no ha sido implemetado";
        }
    }
}
