﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class LineaProducto
    {
        //Atributos
        private string cantidad;
        private string precio;
        //Propiedades
        public string Cantidad { get => cantidad; set => cantidad = value; }
        public string Precio { get => precio; set => precio = value; }
        //Metodos
        public string Organizacion()
        {
            return " Este metodo no ha sido implemetado";
        }
    }
}
