﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class Carrito_compra: LineaProducto
    {
        //Atributos
        private DateTime fechaCreacion;
        //Propiedades
        public DateTime FechaCreacion { get => fechaCreacion; set => fechaCreacion = value; }
        //Metodos
        public string AgregarProducto()
        {
            return " Este metodo no ha sido implemetado";
        }
        public string VentaProducto()
        {
            return " Este metodo no ha sido implemetado";
        }
    }
}
