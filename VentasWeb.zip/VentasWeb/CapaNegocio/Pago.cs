﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class Pago: LineaProducto
    {
        //Atributos
        private string id;
        private string fechaPago;
        private int pagar;
        //Propiedades
        public string Id { get => id; set => id = value; }
        public string FechaPago { get => fechaPago; set => fechaPago = value; }
        public int Pagar { get => pagar; set => pagar = value; }

        //Metodos
        public string Efectivo()
        {
            return " Este metodo no ha sido implemetado";
        }
        public string Tarjeta()
        {
            return " Este metodo no ha sido implemetado";
        }
    }
}
