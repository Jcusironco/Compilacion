﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class Laboratorio
    {
        private string area;
        private string nombre;
        private string direccion;
        private int codigo;

        //propiedades
        public string Area
        {
            get { return area; } // lectura de atributos
            set { area = value; }// escritura del atributo
        }
        public string Nombre
        {
            get { return nombre; } // lectura de atributos
            set { nombre = value; }// escritura del atributo
        }
        public string Direccion
        {
            get { return direccion; } // lectura de atributos
            set { direccion = value; }// escritura del atributo
        }
        public int Codigo
        {
            get { return codigo; } // lectura de atributos
            set { codigo = value; }// escritura del atributo
        }

        // Metodos u operaciones
        public string Enseñar()
        {
            return " no se ha implementado el metodo enseñar";
        }
        public string Aprobar()
        {
            return " no se ha implementado el metodo aprobar ";
        }
        public string Invetigar()
        {
            return " no se ha implementado el metodo investigar ";
        }
    }
}
