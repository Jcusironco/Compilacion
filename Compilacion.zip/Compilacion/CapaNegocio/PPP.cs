﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class PPP
    {
        // atributos
        private string apellidos;
        private string nombres;
        private int edad;
        private string profesion;
        private int dni;

        //propiedades
        public string Apellidos
        {
            get { return apellidos; } // lectura de atributos
            set { apellidos = value; }// escritura del atributo
        }
        public string Nombres
        {
            get { return nombres; } // lectura de atributos
            set { nombres = value; }// escritura del atributo
        }
        public int Edad
        {
            get { return edad; } // lectura de atributos
            set { edad = value; }// escritura del atributo
        }
        public string Profesion
        {
            get { return profesion; } // lectura de atributos
            set { profesion = value; }// escritura del atributo
        }
        public int Dni
        {
            get { return dni; } // lectura de atributos
            set { dni = value; }// escritura del atributo
        }

        // Metodos u operaciones
        public string Trabajar()
        {
            return " no se ha implementado el metodo trabajar";
        }
        public string Experimentar()
        {
            return " no se ha implementado el metodo Experimentar";
        }

        public string Aprender()
        {
            return " no se ha implementado el metodo aprender";
        }
    }
}
