﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class Asignatura
    {
        // atributos
        private string cursos;
        private  int horario;
        private int codigo;
        private string lugarFuncionamiento;
 
        //propiedades
        public string Cursos
        {
            get { return cursos; } // lectura de atributos
            set { cursos = value; }// escritura del atributo
        }
        public int Horario
        {
            get { return horario; } // lectura de atributos
            set { horario = value; }// escritura del atributo
        }
        public int Codigo
        {
            get { return codigo; } // lectura de atributos
            set { codigo = value; }// escritura del atributo
        }
        public string LugarFuncionamiento
        {
            get { return this.lugarFuncionamiento; } // lectura de atributos
            set { this.lugarFuncionamiento = value; }// escritura del atributo
        }
        // Metodos u operaciones
        public string Estudiar()
        {
            return " no se ha implementado el metodo estudiar";
        }
        public string Planificar()
        {
            return " no se ha implementado el metodo planificar";
        }
        public string Aprobar()
        {
            return " no se ha implementado el metodo aprobar";
        }
    }
}
    