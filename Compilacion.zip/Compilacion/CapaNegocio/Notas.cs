﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class Notas
    {
        private string alumno;
        private string cursos;
        private int codigo;

        //propiedades
        public string Alumno
        {
            get { return alumno; } // lectura de atributos
            set { alumno = value; }// escritura del atributo
        }
        public string Cursos
        {
            get { return cursos; } // lectura de atributos
            set { cursos = value; }// escritura del atributo
        }
        public int Codigo
        {
            get { return codigo; } // lectura de atributos
            set { codigo = value; }// escritura del atributo
        }
        // Metodos u operaciones
        public string Promedios()
        {
            return " no se ha implementado el metodo promedio";
        }
        public string Desaprobados()
        {
            return " no se ha implementado el metodo desaprobados";
        }
        public string Aprobados()
        {
            return " no se ha implementado el metodo aprobados";
        }
    }
}
