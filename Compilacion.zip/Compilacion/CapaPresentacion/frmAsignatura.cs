﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmAsignatura : Form
    {
        public frmAsignatura()
        {
            InitializeComponent();
        }
        //istanciar la clase a traves de un objeto
        // en esta parte del codigo se declara variables globales
        CapaNegocio.Asignatura  Area = new CapaNegocio.Asignatura();
        private void btnLeer_Click(object sender, EventArgs e)
        {
            string cursos = txtCursos.Text;
            int horario = int.Parse(txtHorario.Text);
            int codigo = int.Parse(txtCodigo.Text);
            string lugarFuncionamiento = txtLugarFuncionamiento.Text;
            Area.Cursos = cursos;
            Area.Horario = horario;
            Area.Codigo = codigo;
            Area.LugarFuncionamiento = lugarFuncionamiento;
            MessageBox.Show("Se han registrado correctamente los datos de la asignatura");
        }
        private void btnEscribir_Click_1(object sender, EventArgs e)
        {
            string cursos = Area.Cursos;
            int horario = Area.Horario;
            int codigo = Area.Codigo;
            string lugarFuncionamiento = Area.LugarFuncionamiento;

            MessageBox.Show("cursos: " + cursos + "horario: " + horario + "codigo: " + codigo + "lugar de funcionamiento: " + lugarFuncionamiento);
        }

        private void btnEstudiar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Area.Estudiar());
        }

        private void btnPlanificar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Area.Planificar());
        }

        private void btnAprobar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Area.Aprobar());
        }
    }
}
