﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmJefePractica : Form
    {
        public frmJefePractica()
        {
            InitializeComponent();
        }
        //istanciar la clase a traves de un objeto
        // en esta parte del codigo se declara variables globales
        CapaNegocio.JefePractica Docente1 = new CapaNegocio.JefePractica();
        private void btnLeer_Click(object sender, EventArgs e)
        {
            string apellidos = txtApellidos.Text;
            string nombres = txtNombres.Text;
            int edad = int.Parse(txtEdad.Text);
            int dni = int.Parse(txtDni.Text);
            string fechaNacieminto = txtFechaNacimiento.Text;
            string profesion = txtProfesion.Text;
            Docente1.Apellidos = apellidos;
            Docente1.Nombres = nombres;
            Docente1.Edad = edad;
            Docente1.Dni = dni;
            Docente1.FechaNacimiento = fechaNacieminto;
            Docente1.Profesion = profesion;
            MessageBox.Show("Se han registrado correctamente los datos del Docente1");

        }
        private void btnEscribir_Click_1(object sender, EventArgs e)
        {
            string apellidos = Docente1.Apellidos;
            string nombres = Docente1.Nombres;
            int edad = Docente1.Edad;
            int dni = Docente1.Dni;
            string fechaNacieminto = Docente1.FechaNacimiento;
            string profesion = Docente1.Profesion;
            MessageBox.Show("Apellidos: " + apellidos + "Nombres: " + nombres + "Edad: " + edad + "Dni:" + dni + "fecha de naciemiento: " + fechaNacieminto + "Profesion" + profesion);

        }

        private void btnEnseñar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Docente1.Enseñar());
        }

        private void btnTrabajar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Docente1.Trabajar());
        }

        private void btnAprobar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Docente1.Aprobar());
        }

        private void btnDesaprobar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Docente1.Desaprobar());
        }
    }
}
