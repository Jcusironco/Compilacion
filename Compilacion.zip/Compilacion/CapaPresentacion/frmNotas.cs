﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmNotas : Form
    {
        public frmNotas()
        {
            InitializeComponent();
        }

        //istanciar la clase a traves de un objeto
        // en esta parte del codigo se declara variables globales
        CapaNegocio.Notas Resul = new CapaNegocio.Notas();
        private void btnLeer_Click(object sender, EventArgs e)
        {
            string alumno= txtAlumno.Text;
            string cursos = txtCursos.Text;
            int codigo = int.Parse(txtCodigo.Text);
            Resul.Alumno = alumno;
            Resul.Cursos = cursos;
            Resul.Codigo = codigo;
            MessageBox.Show("Se han registrado correctamente los datos");
        }
        private void btnPromedios_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Resul.Promedios());
        }

        private void btnDesaprobados_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Resul.Desaprobados());
        }

        private void btnAprobados_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Resul.Aprobados());
        }

        private void btnEscribir_Click_1(object sender, EventArgs e)
        {
            string alumno = Resul.Alumno;
            string cursos = Resul.Cursos;
            int codigo = Resul.Codigo;

            MessageBox.Show("Alumno: " + alumno + "Cursos: " + cursos + "Codigo: " + codigo);
        }
    }
}
