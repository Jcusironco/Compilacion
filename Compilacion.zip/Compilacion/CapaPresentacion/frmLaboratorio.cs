﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmLaboratorio : Form
    {
        public frmLaboratorio()
        {
            InitializeComponent();
        }
        //istanciar la clase a traves de un objeto
        // en esta parte del codigo se declara variables globales
        CapaNegocio.Laboratorio Metodo = new CapaNegocio.Laboratorio();
        private void btnLeer_Click(object sender, EventArgs e)
        {
            string area = txtArea.Text;
            string nombre = txtNombre.Text;
            string direccion = txtDireccion.Text;
            int codigo = int.Parse(txtCodigo.Text);
            Metodo.Area = area;
            Metodo.Nombre = nombre;
            Metodo.Direccion = direccion;
            Metodo.Codigo = codigo;
            MessageBox.Show("Se han registrado correctamente los datos del metodo");
        }
        private void btnEscribir_Click(object sender, EventArgs e)
        {
            //mostrar los datos almacenados en el objeto1
            string area = Metodo.Area;
            string nombre = Metodo.Nombre;
            string direccion = Metodo.Direccion;
            int codigo = Metodo.Codigo;

            MessageBox.Show("Area: " + area + "Nombre: " + nombre + "Direccion: " + direccion + "Codigo: " + codigo);
        }

        private void btnEnseñar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Metodo.Enseñar());
        }

        private void btnAprobar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Metodo.Aprobar());
        }

        private void btnInvestigar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Metodo.Invetigar());
        }

    }
}
