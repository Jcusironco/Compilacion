﻿
namespace CapaPresentacion
{
    partial class frmNotas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLeer = new System.Windows.Forms.Button();
            this.btnEscribir = new System.Windows.Forms.Button();
            this.txtCursos = new System.Windows.Forms.TextBox();
            this.txtAlumno = new System.Windows.Forms.TextBox();
            this.txtCodigo = new System.Windows.Forms.TextBox();
            this.btnPromedios = new System.Windows.Forms.Button();
            this.btnDesaprobados = new System.Windows.Forms.Button();
            this.btnAprobados = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnLeer
            // 
            this.btnLeer.Location = new System.Drawing.Point(257, 54);
            this.btnLeer.Name = "btnLeer";
            this.btnLeer.Size = new System.Drawing.Size(75, 23);
            this.btnLeer.TabIndex = 0;
            this.btnLeer.Text = "Leer";
            this.btnLeer.UseVisualStyleBackColor = true;
            this.btnLeer.Click += new System.EventHandler(this.btnLeer_Click);
            // 
            // btnEscribir
            // 
            this.btnEscribir.Location = new System.Drawing.Point(257, 102);
            this.btnEscribir.Name = "btnEscribir";
            this.btnEscribir.Size = new System.Drawing.Size(75, 23);
            this.btnEscribir.TabIndex = 1;
            this.btnEscribir.Text = "Escribir";
            this.btnEscribir.UseVisualStyleBackColor = true;
            this.btnEscribir.Click += new System.EventHandler(this.btnEscribir_Click_1);
            // 
            // txtCursos
            // 
            this.txtCursos.Location = new System.Drawing.Point(128, 81);
            this.txtCursos.Name = "txtCursos";
            this.txtCursos.Size = new System.Drawing.Size(100, 20);
            this.txtCursos.TabIndex = 2;
            // 
            // txtAlumno
            // 
            this.txtAlumno.Location = new System.Drawing.Point(128, 44);
            this.txtAlumno.Name = "txtAlumno";
            this.txtAlumno.Size = new System.Drawing.Size(100, 20);
            this.txtAlumno.TabIndex = 3;
            // 
            // txtCodigo
            // 
            this.txtCodigo.Location = new System.Drawing.Point(128, 127);
            this.txtCodigo.Name = "txtCodigo";
            this.txtCodigo.Size = new System.Drawing.Size(100, 20);
            this.txtCodigo.TabIndex = 4;
            // 
            // btnPromedios
            // 
            this.btnPromedios.Location = new System.Drawing.Point(34, 189);
            this.btnPromedios.Name = "btnPromedios";
            this.btnPromedios.Size = new System.Drawing.Size(75, 23);
            this.btnPromedios.TabIndex = 6;
            this.btnPromedios.Text = "Promedios";
            this.btnPromedios.UseVisualStyleBackColor = true;
            this.btnPromedios.Click += new System.EventHandler(this.btnPromedios_Click);
            // 
            // btnDesaprobados
            // 
            this.btnDesaprobados.Location = new System.Drawing.Point(137, 189);
            this.btnDesaprobados.Name = "btnDesaprobados";
            this.btnDesaprobados.Size = new System.Drawing.Size(91, 23);
            this.btnDesaprobados.TabIndex = 7;
            this.btnDesaprobados.Text = "Desaprobados";
            this.btnDesaprobados.UseVisualStyleBackColor = true;
            this.btnDesaprobados.Click += new System.EventHandler(this.btnDesaprobados_Click);
            // 
            // btnAprobados
            // 
            this.btnAprobados.Location = new System.Drawing.Point(257, 189);
            this.btnAprobados.Name = "btnAprobados";
            this.btnAprobados.Size = new System.Drawing.Size(75, 23);
            this.btnAprobados.TabIndex = 8;
            this.btnAprobados.Text = "Aprobados";
            this.btnAprobados.UseVisualStyleBackColor = true;
            this.btnAprobados.Click += new System.EventHandler(this.btnAprobados_Click);
            // 
            // frmNotas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(381, 273);
            this.Controls.Add(this.btnAprobados);
            this.Controls.Add(this.btnDesaprobados);
            this.Controls.Add(this.btnPromedios);
            this.Controls.Add(this.txtCodigo);
            this.Controls.Add(this.txtAlumno);
            this.Controls.Add(this.txtCursos);
            this.Controls.Add(this.btnEscribir);
            this.Controls.Add(this.btnLeer);
            this.Name = "frmNotas";
            this.Text = "frmNotas";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLeer;
        private System.Windows.Forms.Button btnEscribir;
        private System.Windows.Forms.TextBox txtCursos;
        private System.Windows.Forms.TextBox txtAlumno;
        private System.Windows.Forms.TextBox txtCodigo;
        private System.Windows.Forms.Button btnPromedios;
        private System.Windows.Forms.Button btnDesaprobados;
        private System.Windows.Forms.Button btnAprobados;
    }
}