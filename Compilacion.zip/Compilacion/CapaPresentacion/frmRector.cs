﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmRector : Form
    {
        public frmRector()
        {
            InitializeComponent();
        }
        //istanciar la clase a traves de un objeto
        // en esta parte del codigo se declara variables globales
        CapaNegocio.Rector Vrector = new CapaNegocio.Rector();
        private void btnLeer_Click(object sender, EventArgs e)
        {
            string apellidos = txtApellidos.Text;
            string nombres = txtNombres.Text;
            int edad = int.Parse(txtEdad.Text);
            int dni = int.Parse(txtDni.Text);
            string profesion = txtProfesion.Text;
            Vrector.Apellidos = apellidos;
            Vrector.Nombres = nombres;
            Vrector.Edad = edad;
            Vrector.Dni = dni;
            Vrector.Profesion = profesion;
            MessageBox.Show("Se han registrado correctamente los datos");
        }
        private void btnEscribir_Click_1(object sender, EventArgs e)
        {
            string apellidos = Vrector.Apellidos;
            string nombres = Vrector.Nombres;
            int edad = Vrector.Edad;
            int dni = Vrector.Dni;
            string profesion = Vrector.Profesion;
            MessageBox.Show("Apellidos: " + apellidos + "Nombres: " + nombres + "Edad: " + edad + "Dni:" + dni + "Profesion" + profesion);
        }
        private void btnEnseñar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Vrector.Enseñar());
        }

        private void btnTrabajar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Vrector.Trabajar());
        }

        private void btnAprobar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Vrector.Aprobar());
        }
    }
}
