﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmPPP : Form
    {
        public frmPPP()
        {
            InitializeComponent();
        }

        //istanciar la clase a traves de un objeto
        // en esta parte del codigo se declara variables globales
        CapaNegocio.PPP Postulante = new CapaNegocio.PPP();
        private void btnLeer_Click(object sender, EventArgs e)
        {
            string apellidos = txtApellidos.Text;
            string nombres = txtNombres.Text;
            int edad = int.Parse(txtEdad.Text);
            string profesion = txtProfesion.Text;
            int dni = int.Parse(txtDni.Text);
            Postulante.Apellidos = apellidos;
            Postulante.Nombres = nombres;
            Postulante.Edad = edad;
            Postulante.Profesion = profesion;
            Postulante.Dni = dni;
            MessageBox.Show("Se han registrado correctamente los datos");

        }
        private void btnEscribir_Click_1(object sender, EventArgs e)
        {
            string apellidos = Postulante.Apellidos;
            string nombres = Postulante.Nombres;
            int edad = Postulante.Edad;
            string profesion = Postulante.Profesion;
            int dni = Postulante.Dni;
            MessageBox.Show("Apellidos: " + apellidos + "Nombres: " + nombres + "Edad: " + edad + "Profesion" + profesion + "Dni:" + dni);
        }

        private void btnTrabajar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Postulante.Trabajar());
        }

        private void btnExperimentar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Postulante.Experimentar());
        }

        private void btnAprender_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Postulante.Aprender());
        }
    }
}
