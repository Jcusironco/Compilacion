﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmAlumno : Form
    {
        public frmAlumno()
        {
            InitializeComponent();
        }
        //istanciar la clase a traves de un objeto
        // en esta parte del codigo se declara variables globales
        CapaNegocio.Alumno Alumno1 = new CapaNegocio.Alumno();
        private void btnLeer_Click(object sender, EventArgs e)
        {
            string apellidos = txtApellidos.Text;
            string nombres = txtNombres.Text;
            int edad = int.Parse(txtEdad.Text);
            string lugarNacimiento=txtLugarNacimiento.Text;
            Alumno1.Apellidos = apellidos;
            Alumno1.Nombres = nombres;
            Alumno1.Edad = edad;
            Alumno1.LugaNacimiento = lugarNacimiento;
            MessageBox.Show("Se han registrado correctamente los datos del alumno1");
        }

        private void btnEscribir_Click(object sender, EventArgs e)
        {
            //mostrar los datos almacenados en el objeto1
            string apellidos = Alumno1.Apellidos;
            string nombres = Alumno1.Nombres;
            int edad = Alumno1.Edad;
            string lugarNacimiento = Alumno1.LugaNacimiento;
            MessageBox.Show("Apellidos: " +apellidos+  "Nombres: " +nombres+ "Edad: " +edad+ "lugar de naciemiento: " +lugarNacimiento);
        }

        private void btnEstudiar_Click(object sender, EventArgs e)
        {
            //mostrar el metodo u operacion Estudiar
            MessageBox.Show(Alumno1.Estudiar());
        }

        private void btnTrabajar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Alumno1.Trabajar());
        }

        private void btnAprovarExamen_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Alumno1.AprobarExamen());
        }

    }
}
